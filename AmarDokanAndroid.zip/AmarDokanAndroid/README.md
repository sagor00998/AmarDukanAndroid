# আমার দোকান — Men's Fashion Android App

This project wraps the live storefront at https://amardukanmensfashion.netlify.app/ in an Android WebView.

## Build
Open this folder in Android Studio and choose **Build > Build APK(s)**.

Application ID: `com.amardokan.mensfashion`
Version: 1.0 (versionCode 1)

The app needs internet permission because the store is hosted online.
